//App.tsx
import React from 'react';
import './App.css';
import Card from '../src/components/Card'

function App() {
  return (
    <div className="App">
      <Card />
    </div>
  );
}

export default App;
