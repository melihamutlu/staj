import React from 'react';
import Tablo from './components/Tablo';

function App() {
  return (
    <div>
      <Tablo/>
    </div>
  );
}

export default App;
